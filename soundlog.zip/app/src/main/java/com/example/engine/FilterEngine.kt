package com.example.engine

import com.example.data.models.Listen
import com.example.data.models.QuarantineReason
import com.example.data.models.QuarantinedItem
import com.example.data.models.FilterResult
import java.util.Locale
import java.util.regex.Pattern

object FilterEngine {

    private val EPISODE_PATTERN = Pattern.compile("(episode|ep\\.)\\s*\\d+", Pattern.CASE_INSENSITIVE)
    private val SPOKEN_PATTERN = Pattern.compile("(podcast|audiobook|spoken word|interview|q&a|livestream|voice note|radio show|audiobook|book club)", Pattern.CASE_INSENSITIVE)
    private val CHAPTER_PATTERN = Pattern.compile("(chapter|ch\\.)\\s*\\d+", Pattern.CASE_INSENSITIVE)

    fun generateCompositeId(listen: Listen): String {
        val cleanArtist = listen.trackMetadata.artistName.trim().lowercase(Locale.ROOT)
        val cleanTrack = listen.trackMetadata.trackName.trim().lowercase(Locale.ROOT)
        return "${cleanArtist}_${cleanTrack}_${listen.listenedAt}"
    }

    fun evaluateScrobbles(
        rawListens: List<Listen>,
        customRules: List<String> = emptyList(),
        restoredIds: Set<String> = emptySet(),
        manualQuarantineIds: Set<String> = emptySet()
    ): FilterResult {
        val passed = mutableListOf<Listen>()
        val quarantined = mutableListOf<QuarantinedItem>()

        // Sort chronologically ascending to evaluate time differences accurately
        val sortedListens = rawListens.sortedBy { it.listenedAt }

        for (i in sortedListens.indices) {
            val current = sortedListens[i]
            val compId = generateCompositeId(current)

            // If user explicitly restored this item from soft quarantine, let it pass!
            if (restoredIds.contains(compId)) {
                passed.add(current)
                continue
            }

            // If user manually quarantined this item
            if (manualQuarantineIds.contains(compId)) {
                quarantined.add(
                    QuarantinedItem(
                        id = compId,
                        scrobble = current,
                        reason = QuarantineReason.CUSTOM_RULE,
                        details = "Manually flagged by user in Soundlog."
                    )
                )
                continue
            }

            // 1. Time-Window Deduplication (within 30 seconds of identical track)
            if (i > 0) {
                val previous = sortedListens[i - 1]
                val timeDiff = Math.abs(current.listenedAt - previous.listenedAt)

                val sameArtist = current.trackMetadata.artistName.trim().equals(previous.trackMetadata.artistName.trim(), ignoreCase = true)
                val sameTrack = current.trackMetadata.trackName.trim().equals(previous.trackMetadata.trackName.trim(), ignoreCase = true)

                if (sameArtist && sameTrack && timeDiff <= 30) {
                    quarantined.add(
                        QuarantinedItem(
                            id = compId,
                            scrobble = current,
                            reason = QuarantineReason.DUPLICATE_TIME,
                            details = "Identical play within $timeDiff sec of previous scrobble."
                        )
                    )
                    continue
                }
            }

            // 2. Duration Limit check (> 1200 seconds / 20 min without MBID)
            val durationMs = current.trackMetadata.additionalInfo.durationMs
            val hasMbid = !current.trackMetadata.additionalInfo.recordingMbid.isNullOrEmpty() ||
                    !current.trackMetadata.additionalInfo.releaseGroupMbid.isNullOrEmpty()

            if (durationMs != null && durationMs > 1200000L && !hasMbid) {
                quarantined.add(
                    QuarantinedItem(
                        id = compId,
                        scrobble = current,
                        reason = QuarantineReason.DURATION_EXCEEDED,
                        details = "Duration (${durationMs / 60000}m) exceeds 20-min non-music threshold without verified Recording MBID."
                    )
                )
                continue
            }

            // 3. Heuristic & Regex Pattern Engine
            val corpus = "${current.trackMetadata.trackName} ${current.trackMetadata.artistName} ${current.trackMetadata.releaseName ?: ""}"

            if (EPISODE_PATTERN.matcher(corpus).find()) {
                quarantined.add(
                    QuarantinedItem(
                        id = compId,
                        scrobble = current,
                        reason = QuarantineReason.PATTERN_MATCH,
                        details = "Matched episode designation pattern (e.g., 'Episode 42')."
                    )
                )
                continue
            }

            if (SPOKEN_PATTERN.matcher(corpus).find()) {
                quarantined.add(
                    QuarantinedItem(
                        id = compId,
                        scrobble = current,
                        reason = QuarantineReason.PATTERN_MATCH,
                        details = "Matched spoken word/podcast keyword (e.g., 'Podcast', 'Audiobook', 'Interview')."
                    )
                )
                continue
            }

            if (CHAPTER_PATTERN.matcher(corpus).find()) {
                quarantined.add(
                    QuarantinedItem(
                        id = compId,
                        scrobble = current,
                        reason = QuarantineReason.PATTERN_MATCH,
                        details = "Matched chapter designation pattern (e.g., 'Chapter 12')."
                    )
                )
                continue
            }

            // 4. MusicBrainz ID / Tag Validation
            val tags = current.trackMetadata.additionalInfo.musicbrainzTags ?: emptyList()
            val lowerTags = tags.map { it.lowercase(Locale.ROOT) }
            if (lowerTags.any { it in listOf("podcast", "audiobook", "spoken word", "interview", "speech", "radio") }) {
                quarantined.add(
                    QuarantinedItem(
                        id = compId,
                        scrobble = current,
                        reason = QuarantineReason.MBID_INVALID,
                        details = "MusicBrainz group entity tagged as non-music."
                    )
                )
                continue
            }

            // 5. Custom User Filter Rules
            var matchedCustom = false
            for (rule in customRules) {
                if (rule.isBlank()) continue
                if (corpus.contains(rule, ignoreCase = true)) {
                    quarantined.add(
                        QuarantinedItem(
                            id = compId,
                            scrobble = current,
                            reason = QuarantineReason.CUSTOM_RULE,
                            details = "Matched custom user rule: '$rule'"
                        )
                    )
                    matchedCustom = true
                    break
                }
            }
            if (matchedCustom) continue

            // Clean scrobble passes through filter!
            passed.add(current)
        }

        return FilterResult(
            passed = passed.sortedByDescending { it.listenedAt },
            quarantined = quarantined.sortedByDescending { it.flaggedAt }
        )
    }

    /**
     * Compute Obsession Bursts: 3+ replays of a single track within 3 hours
     */
    fun detectObsessionBursts(listens: List<Listen>): List<com.example.data.models.ObsessionBurst> {
        val bursts = mutableListOf<com.example.data.models.ObsessionBurst>()
        val grouped = listens.groupBy { "${it.trackMetadata.artistName.lowercase(Locale.ROOT)} - ${it.trackMetadata.trackName.lowercase(Locale.ROOT)}" }

        val threeHoursSec = 3 * 3600

        for ((_, trackListens) in grouped) {
            if (trackListens.size < 3) continue
            val sorted = trackListens.sortedBy { it.listenedAt }
            var windowStart = 0

            while (windowStart < sorted.size) {
                var windowEnd = windowStart
                while (windowEnd < sorted.size && (sorted[windowEnd].listenedAt - sorted[windowStart].listenedAt) <= threeHoursSec) {
                    windowEnd++
                }

                val count = windowEnd - windowStart
                if (count >= 3) {
                    val sample = sorted[windowStart]
                    bursts.add(
                        com.example.data.models.ObsessionBurst(
                            artistName = sample.trackMetadata.artistName,
                            trackName = sample.trackMetadata.trackName,
                            replayCount = count,
                            timeRangeDescription = "$count replays in 3 hours"
                        )
                    )
                    windowStart = windowEnd
                } else {
                    windowStart++
                }
            }
        }

        return bursts.distinctBy { "${it.artistName}_${it.trackName}" }.take(5)
    }
}
