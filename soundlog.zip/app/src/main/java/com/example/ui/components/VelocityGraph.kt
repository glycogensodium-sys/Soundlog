package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.ListeningActivityItem
import com.example.data.models.ObsessionBurst

@Composable
fun VelocityGraph(
    activityData: List<ListeningActivityItem>,
    obsessionBursts: List<ObsessionBurst>,
    modifier: Modifier = Modifier
) {
    GlassCard(
        modifier = modifier.fillMaxWidth(),
        cornerRadius = 24.dp,
        borderColor = Color(0x3300F0FF)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Timeline,
                        contentDescription = "Velocity",
                        tint = Color(0xFF00F0FF),
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "LISTENING VELOCITY",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                }

                Text(
                    text = "${activityData.size} Days Trend",
                    color = Color(0x80FFFFFF),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // Area Chart
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
            ) {
                if (activityData.isNotEmpty()) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val width = size.width
                        val height = size.height

                        val maxCount = activityData.maxOfOrNull { it.listenCount }?.coerceAtLeast(1) ?: 1
                        val points = activityData.mapIndexed { index, item ->
                            val x = (index.toFloat() / (activityData.size - 1).coerceAtLeast(1)) * width
                            val y = height - ((item.listenCount.toFloat() / maxCount) * (height * 0.8f)) - 10f
                            Offset(x, y)
                        }

                        // Path for stroke line
                        val strokePath = Path().apply {
                            if (points.isNotEmpty()) {
                                moveTo(points.first().x, points.first().y)
                                for (i in 1 until points.size) {
                                    val p0 = points[i - 1]
                                    val p1 = points[i]
                                    val controlX = (p0.x + p1.x) / 2f
                                    cubicTo(controlX, p0.y, controlX, p1.y, p1.x, p1.y)
                                }
                            }
                        }

                        // Fill path
                        val fillPath = Path().apply {
                            addPath(strokePath)
                            if (points.isNotEmpty()) {
                                lineTo(points.last().x, height)
                                lineTo(points.first().x, height)
                                close()
                            }
                        }

                        // Draw Gradient Area
                        drawPath(
                            path = fillPath,
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color(0x6600F0FF),
                                    Color(0x119D4EDD),
                                    Color.Transparent
                                )
                            )
                        )

                        // Draw Stroke Line
                        drawPath(
                            path = strokePath,
                            brush = Brush.horizontalGradient(
                                colors = listOf(
                                    Color(0xFF00F0FF),
                                    Color(0xFF9D4EDD),
                                    Color(0xFFFF007F)
                                )
                            ),
                            style = Stroke(width = 4f)
                        )

                        // Draw data point glowing dots
                        points.forEachIndexed { idx, point ->
                            if (idx % 3 == 0 || idx == points.lastIndex) {
                                drawCircle(
                                    color = Color(0xFF00F0FF),
                                    radius = 5f,
                                    center = point
                                )
                            }
                        }
                    }
                } else {
                    Text(
                        text = "No velocity data available",
                        color = Color(0x66FFFFFF),
                        fontSize = 12.sp,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
            }

            // Obsession Bursts Badges
            if (obsessionBursts.isNotEmpty()) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = "Obsession Bursts",
                            tint = Color(0xFFFF007F),
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "OBSESSION BURSTS DETECTED",
                            color = Color(0xFFFF007F),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        obsessionBursts.take(2).forEach { burst ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Color(0x1AFF007F))
                                    .padding(horizontal = 10.dp, vertical = 8.dp)
                            ) {
                                Column {
                                    Text(
                                        text = "${burst.trackName} - ${burst.artistName}",
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                    Text(
                                        text = burst.timeRangeDescription,
                                        color = Color(0xCCFF007F),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
