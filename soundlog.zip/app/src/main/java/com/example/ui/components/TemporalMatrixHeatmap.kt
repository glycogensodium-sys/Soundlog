package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.DailyActivityItem

@Composable
fun TemporalMatrixHeatmap(
    dailyActivityMap: Map<String, List<DailyActivityItem>>,
    modifier: Modifier = Modifier
) {
    var selectedInfo by remember { mutableStateOf<String?>(null) }

    val dayOrder = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")

    // Find max listen count for intensity scaling
    val maxCount = dailyActivityMap.values.flatMap { list -> list.map { it.listenCount } }
        .maxOfOrNull { it }?.coerceAtLeast(1) ?: 1

    GlassCard(
        modifier = modifier.fillMaxWidth(),
        cornerRadius = 24.dp,
        borderColor = Color(0x339D4EDD)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.GridOn,
                        contentDescription = "Temporal Matrix",
                        tint = Color(0xFF9D4EDD),
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "TEMPORAL LISTENING MATRIX",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                }

                Text(
                    text = "7x24 Day/Hour Heat",
                    color = Color(0x80FFFFFF),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // Selection info callout
            selectedInfo?.let { info ->
                Text(
                    text = info,
                    color = Color(0xFF00F0FF),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // Grid Layout
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Hour Headers (0, 4, 8, 12, 16, 20)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Spacer(modifier = Modifier.width(32.dp)) // Day label offset
                    Row(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        listOf(0, 4, 8, 12, 16, 20).forEach { hour ->
                            Text(
                                text = "${hour}h",
                                color = Color(0x66FFFFFF),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                // 7 Days Rows
                dayOrder.forEach { dayName ->
                    val dayItems = dailyActivityMap[dayName] ?: (0..23).map { DailyActivityItem(it, 0) }
                    val shortDay = dayName.take(3)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Day Label
                        Text(
                            text = shortDay,
                            color = Color(0x99FFFFFF),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.width(28.dp)
                        )

                        // 24 Hour Heatmap Blocks
                        Row(
                            modifier = Modifier.weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            (0..23).forEach { hour ->
                                val item = dayItems.find { it.hour == hour } ?: DailyActivityItem(hour, 0)
                                val intensity = (item.listenCount.toFloat() / maxCount).coerceIn(0f, 1f)

                                val blockColor = when {
                                    intensity > 0.75f -> Color(0xFF00F0FF)
                                    intensity > 0.50f -> Color(0xFF9D4EDD)
                                    intensity > 0.25f -> Color(0x999D4EDD)
                                    intensity > 0.05f -> Color(0x339D4EDD)
                                    else -> Color(0x11FFFFFF)
                                }

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(16.dp)
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(blockColor)
                                        .clickable {
                                            selectedInfo = "$dayName at ${hour}:00 - ${item.listenCount} scrobbles"
                                        }
                                )
                            }
                        }
                    }
                }
            }

            // Heat Legend
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Less",
                    color = Color(0x66FFFFFF),
                    fontSize = 10.sp,
                    modifier = Modifier.padding(end = 4.dp)
                )

                listOf(
                    Color(0x11FFFFFF),
                    Color(0x339D4EDD),
                    Color(0x999D4EDD),
                    Color(0xFF9D4EDD),
                    Color(0xFF00F0FF)
                ).forEach { col ->
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .padding(1.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(col)
                    )
                }

                Text(
                    text = "More",
                    color = Color(0x66FFFFFF),
                    fontSize = 10.sp,
                    modifier = Modifier.padding(start = 4.dp)
                )
            }
        }
    }
}
