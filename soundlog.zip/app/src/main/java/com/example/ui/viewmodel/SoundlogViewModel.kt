package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.ListenBrainzRepository
import com.example.data.local.AppDatabase
import com.example.data.local.CustomRuleEntity
import com.example.data.models.*
import com.example.engine.FilterEngine
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class SoundlogUiState(
    val userName: String = "rob",
    val selectedRange: String = "all_time",
    val isSyncing: Boolean = false,
    val rawListens: List<Listen> = emptyList(),
    val cleanListens: List<Listen> = emptyList(),
    val quarantinedItems: List<QuarantinedItem> = emptyList(),
    val topArtists: List<TopArtist> = emptyList(),
    val topReleases: List<TopRelease> = emptyList(),
    val topRecordings: List<TopRecording> = emptyList(),
    val dailyActivity: Map<String, List<DailyActivityItem>> = emptyMap(),
    val listeningActivity: List<ListeningActivityItem> = emptyList(),
    val obsessionBursts: List<ObsessionBurst> = emptyList(),
    val reconciledStats: ReconciledStats = ReconciledStats(
        originalCount = 0,
        cleanCount = 0,
        quarantineDelta = 0,
        cleanPercentage = 100,
        totalHours = 0.0,
        topArtist = "",
        currentStreakDays = 14
    ),
    val errorMessage: String? = null
)

class SoundlogViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val repository = ListenBrainzRepository(database.quarantineDao())

    private val _uiState = MutableStateFlow(SoundlogUiState())
    val uiState: StateFlow<SoundlogUiState> = _uiState.asStateFlow()

    private val restoredIds = mutableSetOf<String>()
    private val manualQuarantineIds = mutableSetOf<String>()
    private val customRulesList = mutableListOf<String>()

    init {
        // Observe custom rules from Room
        viewModelScope.launch {
            database.quarantineDao().getCustomRules().collect { rules ->
                customRulesList.clear()
                customRulesList.addAll(rules.map { it.pattern })
                reevaluateFilter()
            }
        }

        loadUserData(_uiState.value.userName, _uiState.value.selectedRange)
    }

    fun setUserName(newUserName: String) {
        if (newUserName.isBlank() || newUserName == _uiState.value.userName) return
        _uiState.update { it.copy(userName = newUserName) }
        loadUserData(newUserName, _uiState.value.selectedRange)
    }

    fun setSelectedRange(range: String) {
        _uiState.update { it.copy(selectedRange = range) }
        loadUserData(_uiState.value.userName, range)
    }

    fun refreshData() {
        loadUserData(_uiState.value.userName, _uiState.value.selectedRange)
    }

    private fun loadUserData(userName: String, range: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isSyncing = true, errorMessage = null) }

            try {
                val listens = repository.getRecentListens(userName)
                val artists = repository.getTopArtists(userName, range)
                val releases = repository.getTopReleases(userName, range)
                val recordings = repository.getTopRecordings(userName, range)
                val daily = repository.getDailyActivity(userName)
                val activity = repository.getListeningActivity(userName, range)

                _uiState.update {
                    it.copy(
                        rawListens = listens,
                        topArtists = artists,
                        topReleases = releases,
                        topRecordings = recordings,
                        dailyActivity = daily,
                        listeningActivity = activity,
                        isSyncing = false
                    )
                }

                reevaluateFilter()
            } catch (e: Exception) {
                e.printStackTrace()
                _uiState.update {
                    it.copy(
                        isSyncing = false,
                        errorMessage = "Error syncing with ListenBrainz: ${e.message}"
                    )
                }
            }
        }
    }

    private fun reevaluateFilter() {
        val currentState = _uiState.value
        val filterResult = FilterEngine.evaluateScrobbles(
            rawListens = currentState.rawListens,
            customRules = customRulesList,
            restoredIds = restoredIds,
            manualQuarantineIds = manualQuarantineIds
        )

        // Save quarantined items to Room
        viewModelScope.launch {
            repository.saveQuarantinedItems(filterResult.quarantined, currentState.userName)
        }

        // Calculate hours and stats
        val totalListens = currentState.rawListens.size
        val cleanCount = filterResult.passed.size
        val delta = filterResult.quarantined.size
        val cleanPct = if (totalListens > 0) Math.round((cleanCount.toDouble() / totalListens) * 100).toInt() else 100

        // Estimate scrobbles hours (average 3.5 minutes per track)
        val totalHours = (cleanCount * 3.5) / 60.0

        val topArtistName = currentState.topArtists.firstOrNull()?.artistName ?: "None"

        val bursts = FilterEngine.detectObsessionBursts(filterResult.passed)

        _uiState.update {
            it.copy(
                cleanListens = filterResult.passed,
                quarantinedItems = filterResult.quarantined,
                obsessionBursts = bursts,
                reconciledStats = ReconciledStats(
                    originalCount = totalListens,
                    cleanCount = cleanCount,
                    quarantineDelta = delta,
                    cleanPercentage = cleanPct,
                    totalHours = totalHours,
                    topArtist = topArtistName,
                    currentStreakDays = 14
                )
            )
        }
    }

    fun restoreScrobble(id: String) {
        restoredIds.add(id)
        manualQuarantineIds.remove(id)
        viewModelScope.launch {
            repository.restoreItem(id)
        }
        reevaluateFilter()
    }

    fun purgeScrobble(id: String) {
        manualQuarantineIds.remove(id)
        viewModelScope.launch {
            repository.purgeItem(id)
        }
        reevaluateFilter()
    }

    fun addCustomFilterRule(rule: String) {
        if (rule.isBlank()) return
        viewModelScope.launch {
            database.quarantineDao().insertCustomRule(
                CustomRuleEntity(pattern = rule, isRegex = false)
            )
        }
    }
}
