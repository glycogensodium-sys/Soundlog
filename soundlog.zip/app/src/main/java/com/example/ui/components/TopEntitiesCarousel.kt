package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.api.ListenBrainzApi
import com.example.data.models.TopArtist
import com.example.data.models.TopRecording
import com.example.data.models.TopRelease

@Composable
fun TopEntitiesCarousel(
    topArtists: List<TopArtist>,
    topReleases: List<TopRelease>,
    topRecordings: List<TopRecording>,
    selectedRange: String,
    onRangeSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var activeTab by remember { mutableStateOf(0) } // 0: Artists, 1: Releases, 2: Tracks

    GlassCard(
        modifier = modifier.fillMaxWidth(),
        cornerRadius = 24.dp,
        borderColor = Color(0x33FF007F)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header & Category Tabs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TabPill(
                        label = "Artists",
                        icon = Icons.Default.Person,
                        isSelected = activeTab == 0,
                        onClick = { activeTab = 0 }
                    )
                    TabPill(
                        label = "Albums",
                        icon = Icons.Default.Album,
                        isSelected = activeTab == 1,
                        onClick = { activeTab = 1 }
                    )
                    TabPill(
                        label = "Tracks",
                        icon = Icons.Default.LibraryMusic,
                        isSelected = activeTab == 2,
                        onClick = { activeTab = 2 }
                    )
                }

                // Range selector
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("week", "month", "year", "all_time").forEach { range ->
                        val isSel = selectedRange == range
                        Text(
                            text = when(range) {
                                "week" -> "W"
                                "month" -> "M"
                                "year" -> "Y"
                                else -> "ALL"
                            },
                            color = if (isSel) Color(0xFF00F0FF) else Color(0x66FFFFFF),
                            fontSize = 11.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier
                                .clip(CircleShape)
                                .clickable { onRangeSelect(range) }
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            // Horizontal Carousel
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                when (activeTab) {
                    0 -> items(topArtists) { artist ->
                        ArtistCard(artist)
                    }
                    1 -> items(topReleases) { release ->
                        ReleaseCard(release)
                    }
                    2 -> items(topRecordings) { recording ->
                        RecordingCard(recording)
                    }
                }
            }
        }
    }
}

@Composable
private fun TabPill(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (isSelected) Color(0xFFFF007F) else Color(0x1AFFFFFF))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isSelected) Color.White else Color(0x99FFFFFF),
                modifier = Modifier.size(14.dp)
            )
            Text(
                text = label,
                color = if (isSelected) Color.White else Color(0x99FFFFFF),
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
            )
        }
    }
}

@Composable
private fun ArtistCard(artist: TopArtist) {
    Box(
        modifier = Modifier
            .width(130.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0x1AFFFFFF))
            .padding(12.dp)
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Color(0x339D4EDD)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = artist.artistName.take(1).uppercase(),
                    color = Color(0xFF00F0FF),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Text(
                text = artist.artistName,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )

            Text(
                text = "${artist.listenCount} listens",
                color = Color(0xFF00F0FF),
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun ReleaseCard(release: TopRelease) {
    val artworkUrl = remember(release.releaseMbid) {
        ListenBrainzApi.getCoverArtUrl(release.releaseMbid)
    }

    Box(
        modifier = Modifier
            .width(140.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0x1AFFFFFF))
            .padding(10.dp)
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Album Art Box
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0x33000000)),
                contentAlignment = Alignment.Center
            ) {
                if (artworkUrl.isNotEmpty()) {
                    AsyncImage(
                        model = artworkUrl,
                        contentDescription = release.releaseName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Album,
                        contentDescription = "Album",
                        tint = Color(0x66FFFFFF),
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            Text(
                text = release.releaseName,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )

            Text(
                text = release.artistName,
                color = Color(0x99FFFFFF),
                fontSize = 10.sp,
                maxLines = 1
            )

            Text(
                text = "${release.listenCount} plays",
                color = Color(0xFFFF007F),
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun RecordingCard(recording: TopRecording) {
    Box(
        modifier = Modifier
            .width(140.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0x1AFFFFFF))
            .padding(12.dp)
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = Icons.Default.LibraryMusic,
                contentDescription = "Track",
                tint = Color(0xFF00F0FF),
                modifier = Modifier.size(24.dp)
            )

            Text(
                text = recording.trackName,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )

            Text(
                text = recording.artistName,
                color = Color(0x99FFFFFF),
                fontSize = 11.sp,
                maxLines = 1
            )

            Text(
                text = "${recording.listenCount} plays",
                color = Color(0xFF39FF14),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
