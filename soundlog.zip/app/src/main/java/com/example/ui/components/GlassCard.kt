package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 20.dp,
    borderColor: Color = Color(0x33FFFFFF),
    borderWidth: Dp = 1.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)

    val glassBackground = Brush.verticalGradient(
        colors = listOf(
            Color(0x1AFFFFFF), // 10% white top
            Color(0x0AFFFFFF)  // 4% white bottom
        )
    )

    var boxModifier = modifier
        .shadow(
            elevation = 12.dp,
            shape = shape,
            ambientColor = Color.Black,
            spotColor = Color(0x4000F0FF)
        )
        .clip(shape)
        .background(glassBackground)
        .border(width = borderWidth, color = borderColor, shape = shape)

    if (onClick != null) {
        boxModifier = boxModifier.clickable(onClick = onClick)
    }

    Box(
        modifier = boxModifier.padding(16.dp),
        content = content
    )
}
