package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.ReconciledStats

@Composable
fun CleanStatsHero(
    stats: ReconciledStats,
    onQuarantineClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Card 1: Total Hours
            StatCard(
                title = "SCROBBLED HOURS",
                value = "%.1f hrs".format(stats.totalHours),
                subtext = "${stats.originalCount} Total Listens",
                icon = Icons.Default.Schedule,
                iconTint = Color(0xFF00F0FF),
                modifier = Modifier.weight(1f)
            )

            // Card 2: Clean Music %
            StatCard(
                title = "CLEAN MUSIC RATE",
                value = "${stats.cleanPercentage}%",
                subtext = "-${stats.quarantineDelta} non-music purged",
                icon = Icons.Default.CleaningServices,
                iconTint = Color(0xFF39FF14),
                onClick = onQuarantineClick,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Card 3: Top Artist
            StatCard(
                title = "TOP ARTIST",
                value = stats.topArtist.ifEmpty { "None" },
                subtext = "Most played entity",
                icon = Icons.Default.MusicNote,
                iconTint = Color(0xFF9D4EDD),
                modifier = Modifier.weight(1f)
            )

            // Card 4: Streak
            StatCard(
                title = "LISTENING STREAK",
                value = "${stats.currentStreakDays} Days",
                subtext = "Active daily stream",
                icon = Icons.Default.LocalFireDepartment,
                iconTint = Color(0xFFFF007F),
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    subtext: String,
    icon: ImageVector,
    iconTint: Color,
    onClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    GlassCard(
        modifier = modifier,
        onClick = onClick,
        cornerRadius = 20.dp,
        borderColor = iconTint.copy(alpha = 0.3f)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    color = Color(0x99FFFFFF),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = iconTint,
                    modifier = Modifier.size(18.dp)
                )
            }

            Text(
                text = value,
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black
            )

            Text(
                text = subtext,
                color = Color(0x80FFFFFF),
                fontSize = 11.sp,
                fontWeight = FontWeight.Normal
            )
        }
    }
}
