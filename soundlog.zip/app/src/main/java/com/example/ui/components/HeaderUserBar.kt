package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HeaderUserBar(
    currentUserName: String,
    onUserNameSubmit: (String) -> Unit,
    quarantineCount: Int,
    isSyncing: Boolean,
    onRefresh: () -> Unit,
    onOpenQuarantineAudit: () -> Unit,
    modifier: Modifier = Modifier
) {
    var searchText by remember(currentUserName) { mutableStateOf(currentUserName) }
    val keyboardController = LocalSoftwareKeyboardController.current

    val presetUsers = listOf("rob", "metabrainz", "rj", "listenbrainz")

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Brand Title with Glowing Accent
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF00F0FF))
                        .padding(2.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CleaningServices,
                        contentDescription = "Soundlog Icon",
                        tint = Color(0xFF0A0A0C),
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column {
                    Text(
                        text = "SOUNDLOG",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.5.sp
                    )
                    Text(
                        text = "ListenBrainz Glassmorphic Scrobble Cleaner",
                        color = Color(0x99FFFFFF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Sync Refresh Button
            IconButton(
                onClick = onRefresh,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color(0x1AFFFFFF))
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Sync Data",
                    tint = if (isSyncing) Color(0xFF00F0FF) else Color.White
                )
            }
        }

        // Search Bar & Quarantine Badge Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Username Search Input
            OutlinedTextField(
                value = searchText,
                onValueChange = { searchText = it },
                placeholder = { Text("Enter ListenBrainz Username...", color = Color(0x66FFFFFF), fontSize = 13.sp) },
                singleLine = true,
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = Color(0xFF00F0FF)
                    )
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = {
                    if (searchText.isNotBlank()) {
                        onUserNameSubmit(searchText.trim())
                        keyboardController?.hide()
                    }
                }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF00F0FF),
                    unfocusedBorderColor = Color(0x33FFFFFF),
                    focusedContainerColor = Color(0x1A0A0A0C),
                    unfocusedContainerColor = Color(0x1A0A0A0C),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.weight(1f)
            )

            // Soft Quarantine Audit Badge Button
            Surface(
                onClick = onOpenQuarantineAudit,
                shape = RoundedCornerShape(16.dp),
                color = if (quarantineCount > 0) Color(0x33FF007F) else Color(0x1AFFFFFF),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (quarantineCount > 0) Color(0xFFFF007F) else Color(0x33FFFFFF)
                )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CleaningServices,
                        contentDescription = "Quarantine Audit",
                        tint = if (quarantineCount > 0) Color(0xFFFF007F) else Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "$quarantineCount Cleaned",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Quick Preset User Selectors
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Presets:",
                color = Color(0x80FFFFFF),
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )

            presetUsers.forEach { user ->
                val isSelected = user.equals(currentUserName, ignoreCase = true)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) Color(0xFF00F0FF) else Color(0x1AFFFFFF))
                        .clickable { onUserNameSubmit(user) }
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "@$user",
                        color = if (isSelected) Color(0xFF0A0A0C) else Color(0xCCFFFFFF),
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }
    }
}
