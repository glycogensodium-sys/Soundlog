package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.*
import com.example.ui.viewmodel.SoundlogViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SoundlogDashboard(
    viewModel: SoundlogViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var showAuditModal by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Box(modifier = modifier.fillMaxSize()) {
        // Animated Ambient Background
        AmbientGradientCanvas()

        // Main Content Column
        Scaffold(
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets.safeDrawing
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .verticalScroll(scrollState)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header & User Bar
                HeaderUserBar(
                    currentUserName = uiState.userName,
                    onUserNameSubmit = { viewModel.setUserName(it) },
                    quarantineCount = uiState.reconciledStats.quarantineDelta,
                    isSyncing = uiState.isSyncing,
                    onRefresh = { viewModel.refreshData() },
                    onOpenQuarantineAudit = { showAuditModal = true }
                )

                // Error Snackbar Notice
                uiState.errorMessage?.let { error ->
                    Surface(
                        color = Color(0x33FF007F),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = error,
                            color = Color(0xFFFF007F),
                            fontSize = 12.sp,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }

                // 4 Glassmorphic Metric Cards
                CleanStatsHero(
                    stats = uiState.reconciledStats,
                    onQuarantineClick = { showAuditModal = true }
                )

                // Listening Velocity Graph
                VelocityGraph(
                    activityData = uiState.listeningActivity,
                    obsessionBursts = uiState.obsessionBursts
                )

                // Temporal Listening Matrix (7x24 Day/Hour Heatmap)
                TemporalMatrixHeatmap(
                    dailyActivityMap = uiState.dailyActivity
                )

                // Top Entities Carousel (Artists, Albums, Tracks)
                TopEntitiesCarousel(
                    topArtists = uiState.topArtists,
                    topReleases = uiState.topReleases,
                    topRecordings = uiState.topRecordings,
                    selectedRange = uiState.selectedRange,
                    onRangeSelect = { viewModel.setSelectedRange(it) }
                )

                // Live Scrobbles Feed
                LiveListensFeed(
                    listens = uiState.rawListens,
                    quarantinedIds = uiState.quarantinedItems.map { it.id }.toSet()
                )

                Spacer(modifier = Modifier.height(20.dp))
            }
        }

        // Soft Quarantine Audit Slide-Over BottomSheet
        if (showAuditModal) {
            ScrobbleAuditModal(
                quarantinedItems = uiState.quarantinedItems,
                onRestore = { viewModel.restoreScrobble(it) },
                onPurge = { viewModel.purgeScrobble(it) },
                onAddCustomRule = { viewModel.addCustomFilterRule(it) },
                onDismiss = { showAuditModal = false }
            )
        }
    }
}
