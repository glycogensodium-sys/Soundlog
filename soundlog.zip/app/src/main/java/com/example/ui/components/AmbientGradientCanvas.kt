package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

@Composable
fun AmbientGradientCanvas(
    modifier: Modifier = Modifier,
    accentPrimary: Color = Color(0xFF00F0FF),
    accentSecondary: Color = Color(0xFF9D4EDD),
    accentTertiary: Color = Color(0xFFFF007F)
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ambient_bg")

    val pulse1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse1"
    )

    val pulse2 by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(15000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse2"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        // Dark base background `#0A0A0C`
        drawRect(color = Color(0xFF0A0A0C))

        // Ambient Orb 1 (Top Left Electric Cyan)
        val center1 = Offset(
            x = width * (0.2f + 0.3f * pulse1),
            y = height * (0.15f + 0.2f * pulse2)
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    accentPrimary.copy(alpha = 0.22f),
                    accentPrimary.copy(alpha = 0.08f),
                    Color.Transparent
                ),
                center = center1,
                radius = width * 0.75f
            ),
            center = center1,
            radius = width * 0.75f
        )

        // Ambient Orb 2 (Right Center Neon Violet)
        val center2 = Offset(
            x = width * (0.8f - 0.2f * pulse2),
            y = height * (0.45f + 0.25f * pulse1)
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    accentSecondary.copy(alpha = 0.25f),
                    accentSecondary.copy(alpha = 0.06f),
                    Color.Transparent
                ),
                center = center2,
                radius = width * 0.85f
            ),
            center = center2,
            radius = width * 0.85f
        )

        // Ambient Orb 3 (Bottom Left Hot Pink)
        val center3 = Offset(
            x = width * (0.15f + 0.2f * pulse2),
            y = height * (0.8f - 0.2f * pulse1)
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    accentTertiary.copy(alpha = 0.18f),
                    Color.Transparent
                ),
                center = center3,
                radius = width * 0.65f
            ),
            center = center3,
            radius = width * 0.65f
        )
    }
}
