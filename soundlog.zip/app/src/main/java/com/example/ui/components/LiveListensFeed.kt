package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Listen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LiveListensFeed(
    listens: List<Listen>,
    quarantinedIds: Set<String>,
    modifier: Modifier = Modifier
) {
    val dateFormat = SimpleDateFormat("HH:mm • MMM d", Locale.getDefault())

    GlassCard(
        modifier = modifier.fillMaxWidth(),
        cornerRadius = 24.dp,
        borderColor = Color(0x3300F0FF)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = "Recent Listens",
                        tint = Color(0xFF00F0FF),
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "RECENT LISTENS STREAM",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                }

                Text(
                    text = "Live Stream",
                    color = Color(0x80FFFFFF),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // List of Recent Scrobbles
            if (listens.isEmpty()) {
                Text(
                    text = "No recent listens found.",
                    color = Color(0x66FFFFFF),
                    fontSize = 12.sp,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            } else {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listens.take(8).forEach { listen ->
                        val compId = com.example.engine.FilterEngine.generateCompositeId(listen)
                        val isQuarantined = quarantinedIds.contains(compId)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (isQuarantined) Color(0x1AFF007F) else Color(0x0AFFFFFF))
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Text(
                                    text = listen.trackMetadata.trackName,
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                                Text(
                                    text = "${listen.trackMetadata.artistName} • ${listen.trackMetadata.releaseName ?: "Single"}",
                                    color = Color(0x99FFFFFF),
                                    fontSize = 11.sp,
                                    maxLines = 1
                                )
                            }

                            Column(
                                horizontalAlignment = Alignment.End,
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                // Status Pill
                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(if (isQuarantined) Color(0x33FF007F) else Color(0x3339FF14))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = if (isQuarantined) "Quarantined" else "Clean Music",
                                        color = if (isQuarantined) Color(0xFFFF007F) else Color(0xFF39FF14),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Text(
                                    text = dateFormat.format(Date(listen.listenedAt * 1000L)),
                                    color = Color(0x66FFFFFF),
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
