package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "quarantined_scrobbles")
data class QuarantineEntity(
    @PrimaryKey val id: String, // artist_track_timestamp composite key
    val userName: String,
    val artistName: String,
    val trackName: String,
    val releaseName: String?,
    val listenedAt: Long,
    val reason: String, // QuarantineReason name
    val details: String,
    val flaggedAt: Long,
    val isRestored: Boolean = false // User restored false positive
)

@Entity(tableName = "custom_filter_rules")
data class CustomRuleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pattern: String,
    val isRegex: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
