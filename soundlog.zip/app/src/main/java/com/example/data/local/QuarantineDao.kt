package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface QuarantineDao {

    @Query("SELECT * FROM quarantined_scrobbles WHERE userName = :userName ORDER BY listenedAt DESC")
    fun getQuarantinedScrobbles(userName: String): Flow<List<QuarantineEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(entities: List<QuarantineEntity>)

    @Query("UPDATE quarantined_scrobbles SET isRestored = 1 WHERE id = :id")
    suspend fun restoreItem(id: String)

    @Query("DELETE FROM quarantined_scrobbles WHERE id = :id")
    suspend fun purgeItem(id: String)

    @Query("DELETE FROM quarantined_scrobbles WHERE userName = :userName")
    suspend fun clearUserQuarantine(userName: String)

    @Query("SELECT * FROM custom_filter_rules ORDER BY createdAt DESC")
    fun getCustomRules(): Flow<List<CustomRuleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomRule(rule: CustomRuleEntity)

    @Delete
    suspend fun deleteCustomRule(rule: CustomRuleEntity)
}
