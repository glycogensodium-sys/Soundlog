package com.example.data.models

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class ListenBrainzResponse<T>(
    @Json(name = "payload") val payload: T
)

@JsonClass(generateAdapter = true)
data class ListenPayload(
    @Json(name = "listens") val listens: List<Listen> = emptyList(),
    @Json(name = "count") val count: Int = 0,
    @Json(name = "latest_listen_ts") val latestListenTs: Long = 0,
    @Json(name = "user_name") val userName: String = ""
)

@JsonClass(generateAdapter = true)
data class Listen(
    @Json(name = "inserted_at") val insertedAt: Long = 0,
    @Json(name = "listened_at") val listenedAt: Long = 0, // Unix timestamp in seconds
    @Json(name = "recording_msid") val recordingMsid: String = "",
    @Json(name = "user_name") val userName: String = "",
    @Json(name = "track_metadata") val trackMetadata: TrackMetadata = TrackMetadata()
)

@JsonClass(generateAdapter = true)
data class TrackMetadata(
    @Json(name = "artist_name") val artistName: String = "Unknown Artist",
    @Json(name = "track_name") val trackName: String = "Unknown Track",
    @Json(name = "release_name") val releaseName: String? = null,
    @Json(name = "additional_info") val additionalInfo: AdditionalInfo = AdditionalInfo()
)

@JsonClass(generateAdapter = true)
data class AdditionalInfo(
    @Json(name = "artist_names") val artistNames: List<String>? = null,
    @Json(name = "duration_ms") val durationMs: Long? = null,
    @Json(name = "listening_from") val listeningFrom: String? = null,
    @Json(name = "media_player") val mediaPlayer: String? = null,
    @Json(name = "recording_mbid") val recordingMbid: String? = null,
    @Json(name = "artist_mbids") val artistMbids: List<String>? = null,
    @Json(name = "release_mbid") val releaseMbid: String? = null,
    @Json(name = "release_group_mbid") val releaseGroupMbid: String? = null,
    @Json(name = "musicbrainz_tags") val musicbrainzTags: List<String>? = null
)

// Pre-computed Statistics Types
@JsonClass(generateAdapter = true)
data class TopArtist(
    @Json(name = "artist_name") val artistName: String,
    @Json(name = "artist_mbid") val artistMbid: String? = null,
    @Json(name = "listen_count") val listenCount: Int
)

@JsonClass(generateAdapter = true)
data class TopArtistsPayload(
    @Json(name = "artists") val artists: List<TopArtist> = emptyList(),
    @Json(name = "count") val count: Int = 0,
    @Json(name = "total_artist_count") val totalArtistCount: Int = 0,
    @Json(name = "user_id") val userId: String = "",
    @Json(name = "range") val range: String = "all_time"
)

@JsonClass(generateAdapter = true)
data class TopRelease(
    @Json(name = "release_name") val releaseName: String,
    @Json(name = "artist_name") val artistName: String,
    @Json(name = "release_mbid") val releaseMbid: String? = null,
    @Json(name = "artist_mbid") val artistMbid: String? = null,
    @Json(name = "listen_count") val listenCount: Int
)

@JsonClass(generateAdapter = true)
data class TopReleasesPayload(
    @Json(name = "releases") val releases: List<TopRelease> = emptyList(),
    @Json(name = "count") val count: Int = 0,
    @Json(name = "total_release_count") val totalReleaseCount: Int = 0,
    @Json(name = "user_id") val userId: String = "",
    @Json(name = "range") val range: String = "all_time"
)

@JsonClass(generateAdapter = true)
data class TopRecording(
    @Json(name = "track_name") val trackName: String,
    @Json(name = "artist_name") val artistName: String,
    @Json(name = "release_name") val releaseName: String? = null,
    @Json(name = "recording_mbid") val recordingMbid: String? = null,
    @Json(name = "artist_mbids") val artistMbids: List<String>? = null,
    @Json(name = "release_mbid") val releaseMbid: String? = null,
    @Json(name = "listen_count") val listenCount: Int
)

@JsonClass(generateAdapter = true)
data class TopRecordingsPayload(
    @Json(name = "recordings") val recordings: List<TopRecording> = emptyList(),
    @Json(name = "count") val count: Int = 0,
    @Json(name = "total_recording_count") val totalRecordingCount: Int = 0,
    @Json(name = "user_id") val userId: String = "",
    @Json(name = "range") val range: String = "all_time"
)

@JsonClass(generateAdapter = true)
data class DailyActivityItem(
    @Json(name = "hour") val hour: Int,
    @Json(name = "listen_count") val listenCount: Int
)

@JsonClass(generateAdapter = true)
data class DailyActivityPayload(
    @Json(name = "from_ts") val fromTs: Long = 0,
    @Json(name = "to_ts") val toTs: Long = 0,
    @Json(name = "last_updated") val lastUpdated: Long = 0,
    @Json(name = "user_id") val userId: String = "",
    @Json(name = "daily_activity") val dailyActivity: Map<String, List<DailyActivityItem>> = emptyMap()
)

@JsonClass(generateAdapter = true)
data class ListeningActivityItem(
    @Json(name = "from_ts") val fromTs: Long,
    @Json(name = "to_ts") val toTs: Long,
    @Json(name = "listen_count") val listenCount: Int
)

@JsonClass(generateAdapter = true)
data class ListeningActivityPayload(
    @Json(name = "from_ts") val fromTs: Long = 0,
    @Json(name = "to_ts") val toTs: Long = 0,
    @Json(name = "last_updated") val lastUpdated: Long = 0,
    @Json(name = "user_id") val userId: String = "",
    @Json(name = "listening_activity") val listeningActivity: List<ListeningActivityItem> = emptyList()
)

// Soft Quarantine & Filtering Domain Models
enum class QuarantineReason(val title: String) {
    PATTERN_MATCH("Heuristic Regex Pattern"),
    MBID_INVALID("MusicBrainz Category Tag"),
    DUPLICATE_TIME("30s Time-Window Duplicate"),
    DURATION_EXCEEDED("Over 20 Min Length (No MBID)"),
    CUSTOM_RULE("User Custom Filter Rule")
}

data class QuarantinedItem(
    val id: String,
    val scrobble: Listen,
    val reason: QuarantineReason,
    val details: String,
    val flaggedAt: Long = System.currentTimeMillis()
)

data class FilterResult(
    val passed: List<Listen>,
    val quarantined: List<QuarantinedItem>
)

data class ReconciledStats(
    val originalCount: Int,
    val cleanCount: Int,
    val quarantineDelta: Int,
    val cleanPercentage: Int,
    val totalHours: Double,
    val topArtist: String,
    val currentStreakDays: Int
)

data class ObsessionBurst(
    val artistName: String,
    val trackName: String,
    val replayCount: Int,
    val timeRangeDescription: String
)
