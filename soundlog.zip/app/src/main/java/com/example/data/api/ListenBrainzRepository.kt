package com.example.data.api

import com.example.data.local.QuarantineDao
import com.example.data.local.QuarantineEntity
import com.example.data.models.*
import com.example.engine.FilterEngine
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

class ListenBrainzRepository(private val quarantineDao: QuarantineDao) {

    private val api: ListenBrainzApi by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }

        val client = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .addInterceptor(logging)
            .build()

        Retrofit.Builder()
            .baseUrl(ListenBrainzApi.BASE_URL)
            .client(client)
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
            .create(ListenBrainzApi::class.java)
    }

    suspend fun getRecentListens(userName: String): List<Listen> {
        return try {
            val response = api.getRecentListens(userName, count = 100)
            if (response.payload.listens.isNotEmpty()) {
                response.payload.listens
            } else {
                generateDemoListens(userName)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            generateDemoListens(userName)
        }
    }

    suspend fun getTopArtists(userName: String, range: String): List<TopArtist> {
        return try {
            val response = api.getTopArtists(userName, range = range, count = 20)
            if (response.payload.artists.isNotEmpty()) {
                response.payload.artists
            } else {
                generateDemoTopArtists()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            generateDemoTopArtists()
        }
    }

    suspend fun getTopReleases(userName: String, range: String): List<TopRelease> {
        return try {
            val response = api.getTopReleases(userName, range = range, count = 20)
            if (response.payload.releases.isNotEmpty()) {
                response.payload.releases
            } else {
                generateDemoTopReleases()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            generateDemoTopReleases()
        }
    }

    suspend fun getTopRecordings(userName: String, range: String): List<TopRecording> {
        return try {
            val response = api.getTopRecordings(userName, range = range, count = 20)
            if (response.payload.recordings.isNotEmpty()) {
                response.payload.recordings
            } else {
                generateDemoTopRecordings()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            generateDemoTopRecordings()
        }
    }

    suspend fun getDailyActivity(userName: String): Map<String, List<DailyActivityItem>> {
        return try {
            val response = api.getDailyActivity(userName)
            if (response.payload.dailyActivity.isNotEmpty()) {
                response.payload.dailyActivity
            } else {
                generateDemoDailyActivity()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            generateDemoDailyActivity()
        }
    }

    suspend fun getListeningActivity(userName: String, range: String): List<ListeningActivityItem> {
        return try {
            val response = api.getListeningActivity(userName, range = range)
            if (response.payload.listeningActivity.isNotEmpty()) {
                response.payload.listeningActivity
            } else {
                generateDemoListeningActivity()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            generateDemoListeningActivity()
        }
    }

    // Quarantine Room interactions
    fun getLocalQuarantinedScrobbles(userName: String): Flow<List<QuarantineEntity>> {
        return quarantineDao.getQuarantinedScrobbles(userName)
    }

    suspend fun saveQuarantinedItems(items: List<QuarantinedItem>, userName: String) {
        val entities = items.map { item ->
            QuarantineEntity(
                id = item.id,
                userName = userName,
                artistName = item.scrobble.trackMetadata.artistName,
                trackName = item.scrobble.trackMetadata.trackName,
                releaseName = item.scrobble.trackMetadata.releaseName,
                listenedAt = item.scrobble.listenedAt,
                reason = item.reason.name,
                details = item.details,
                flaggedAt = item.flaggedAt,
                isRestored = false
            )
        }
        quarantineDao.insertAll(entities)
    }

    suspend fun restoreItem(id: String) {
        quarantineDao.restoreItem(id)
    }

    suspend fun purgeItem(id: String) {
        quarantineDao.purgeItem(id)
    }

    // Demo Data Generation for Instant Glassmorphic Polish
    private fun generateDemoListens(userName: String): List<Listen> {
        val nowSec = System.currentTimeMillis() / 1000
        return listOf(
            Listen(listenedAt = nowSec - 120, recordingMsid = "msid1", userName = userName,
                trackMetadata = TrackMetadata("The Weeknd", "Blinding Lights", "After Hours")),
            Listen(listenedAt = nowSec - 280, recordingMsid = "msid2", userName = userName,
                trackMetadata = TrackMetadata("Daft Punk", "Get Lucky", "Random Access Memories")),
            // Duplicate item for filter testing
            Listen(listenedAt = nowSec - 295, recordingMsid = "msid2_dup", userName = userName,
                trackMetadata = TrackMetadata("Daft Punk", "Get Lucky", "Random Access Memories")),
            // Non-music podcast item for filter testing
            Listen(listenedAt = nowSec - 600, recordingMsid = "msid_pod", userName = userName,
                trackMetadata = TrackMetadata("Tech Talk Daily", "Episode 42: AI Revolution in Music", "Tech Talk Podcast")),
            Listen(listenedAt = nowSec - 1200, recordingMsid = "msid3", userName = userName,
                trackMetadata = TrackMetadata("Tame Impala", "The Less I Know The Better", "Currents")),
            Listen(listenedAt = nowSec - 1500, recordingMsid = "msid4", userName = userName,
                trackMetadata = TrackMetadata("Kavinsky", "Nightcall", "OutRun")),
            // Audiobook item
            Listen(listenedAt = nowSec - 2200, recordingMsid = "msid_book", userName = userName,
                trackMetadata = TrackMetadata("Audible Books", "Chapter 4: Sci-Fi Audiobooks", "The Galactic Guide")),
            Listen(listenedAt = nowSec - 3000, recordingMsid = "msid5", userName = userName,
                trackMetadata = TrackMetadata("Gorillaz", "Feel Good Inc.", "Demon Days")),
            Listen(listenedAt = nowSec - 3200, recordingMsid = "msid5_replay1", userName = userName,
                trackMetadata = TrackMetadata("Gorillaz", "Feel Good Inc.", "Demon Days")),
            Listen(listenedAt = nowSec - 3400, recordingMsid = "msid5_replay2", userName = userName,
                trackMetadata = TrackMetadata("Gorillaz", "Feel Good Inc.", "Demon Days")),
            Listen(listenedAt = nowSec - 4500, recordingMsid = "msid6", userName = userName,
                trackMetadata = TrackMetadata("Massive Attack", "Teardrop", "Mezzanine")),
            Listen(listenedAt = nowSec - 5800, recordingMsid = "msid7", userName = userName,
                trackMetadata = TrackMetadata("Aphex Twin", "Windowlicker", "Windowlicker")),
            Listen(listenedAt = nowSec - 7200, recordingMsid = "msid8", userName = userName,
                trackMetadata = TrackMetadata("Portishead", "Glory Box", "Dummy")),
            Listen(listenedAt = nowSec - 9000, recordingMsid = "msid9", userName = userName,
                trackMetadata = TrackMetadata("Arctic Monkeys", "Do I Wanna Know?", "AM"))
        )
    }

    private fun generateDemoTopArtists(): List<TopArtist> {
        return listOf(
            TopArtist("Tame Impala", "b924489a-2d85-412f-b4e0-f04bf463b216", 142),
            TopArtist("Daft Punk", "056e4f3e-d50e-4393-8a81-d26f0d3b37b6", 128),
            TopArtist("The Weeknd", "c8b8893d-55e2-45e0-82d6-44487b322a3f", 115),
            TopArtist("Gorillaz", "e215472d-0f2b-429f-b733-a3f12440306c", 98),
            TopArtist("Arctic Monkeys", "ada7a83c-e377-42f7-b323-476940476baa", 84),
            TopArtist("Massive Attack", "e12a4501-c8ef-41e9-9be8-c920f666b60e", 76),
            TopArtist("Kavinsky", "26bc82a1-10c5-4523-90d1-04e4c278783e", 65),
            TopArtist("Radiohead", "a74b1b7f-71a5-4011-9441-d0b5e4122711", 58)
        )
    }

    private fun generateDemoTopReleases(): List<TopRelease> {
        return listOf(
            TopRelease("Currents", "Tame Impala", "f339ef2a-1944-469a-9e1e-257a31f7a2fb", null, 110),
            TopRelease("Random Access Memories", "Daft Punk", "a3301a1c-9941-4775-9279-efd5e23ebc36", null, 98),
            TopRelease("After Hours", "The Weeknd", "2f31f9d5-78e7-497d-9bc2-3c1a2f64d0bc", null, 89),
            TopRelease("Demon Days", "Gorillaz", "3d062e7e-397a-4296-bd7b-7ef7956a70e7", null, 75),
            TopRelease("AM", "Arctic Monkeys", "c5520e5d-f1b2-4d2c-80b6-12bf1b7a701a", null, 68),
            TopRelease("Mezzanine", "Massive Attack", "9e3c9077-85fb-3e3e-bf61-344cb8ddff20", null, 54)
        )
    }

    private fun generateDemoTopRecordings(): List<TopRecording> {
        return listOf(
            TopRecording("The Less I Know The Better", "Tame Impala", "Currents", null, null, null, 88),
            TopRecording("Get Lucky", "Daft Punk", "Random Access Memories", null, null, null, 74),
            TopRecording("Blinding Lights", "The Weeknd", "After Hours", null, null, null, 69),
            TopRecording("Feel Good Inc.", "Gorillaz", "Demon Days", null, null, null, 62),
            TopRecording("Nightcall", "Kavinsky", "OutRun", null, null, null, 55),
            TopRecording("Do I Wanna Know?", "Arctic Monkeys", "AM", null, null, null, 48)
        )
    }

    private fun generateDemoDailyActivity(): Map<String, List<DailyActivityItem>> {
        val map = mutableMapOf<String, List<DailyActivityItem>>()
        val days = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")

        for (day in days) {
            val list = (0..23).map { hour ->
                val count = when {
                    hour in 8..10 -> (15..35).random()
                    hour in 12..14 -> (20..45).random()
                    hour in 18..23 -> (30..65).random()
                    hour in 0..2 -> (10..25).random()
                    else -> (0..8).random()
                }
                DailyActivityItem(hour, count)
            }
            map[day] = list
        }
        return map
    }

    private fun generateDemoListeningActivity(): List<ListeningActivityItem> {
        val now = System.currentTimeMillis() / 1000
        val daySec = 86400L
        return (0..29).map { idx ->
            ListeningActivityItem(
                fromTs = now - ((30 - idx) * daySec),
                toTs = now - ((29 - idx) * daySec),
                listenCount = (20..85).random()
            )
        }.reversed()
    }
}
