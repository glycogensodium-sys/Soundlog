package com.example.data.api

import com.example.data.models.*
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ListenBrainzApi {

    @GET("user/{userName}/listens")
    suspend fun getRecentListens(
        @Path("userName") userName: String,
        @Query("count") count: Int = 100,
        @Query("max_ts") maxTs: Long? = null
    ): ListenBrainzResponse<ListenPayload>

    @GET("stats/user/{userName}/artists")
    suspend fun getTopArtists(
        @Path("userName") userName: String,
        @Query("range") range: String = "all_time",
        @Query("count") count: Int = 25
    ): ListenBrainzResponse<TopArtistsPayload>

    @GET("stats/user/{userName}/releases")
    suspend fun getTopReleases(
        @Path("userName") userName: String,
        @Query("range") range: String = "all_time",
        @Query("count") count: Int = 25
    ): ListenBrainzResponse<TopReleasesPayload>

    @GET("stats/user/{userName}/recordings")
    suspend fun getTopRecordings(
        @Path("userName") userName: String,
        @Query("range") range: String = "all_time",
        @Query("count") count: Int = 25
    ): ListenBrainzResponse<TopRecordingsPayload>

    @GET("stats/user/{userName}/daily-activity")
    suspend fun getDailyActivity(
        @Path("userName") userName: String
    ): ListenBrainzResponse<DailyActivityPayload>

    @GET("stats/user/{userName}/listening-activity")
    suspend fun getListeningActivity(
        @Path("userName") userName: String,
        @Query("range") range: String = "all_time"
    ): ListenBrainzResponse<ListeningActivityPayload>

    companion object {
        const val BASE_URL = "https://api.listenbrainz.org/1/"

        fun getCoverArtUrl(releaseMbid: String?): String {
            if (releaseMbid.isNull_or_empty()) return ""
            return "https://coverartarchive.org/release/$releaseMbid/front"
        }

        private fun String?.isNull_or_empty(): Boolean = this == null || this.trim().isEmpty()

        fun getArtCollageUrl(userName: String, range: String = "week", dimension: Int = 300): String {
            return "${BASE_URL}art/grid/$userName/$range/$dimension/2"
        }
    }
}
